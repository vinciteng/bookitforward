=== Tokokoo Extensions ===

Contributors: tokokoo, satrya
Tags: post type, shortcode, custom css, facebook app
License: GPLv2 or later
Requires at least: 3.5
Tested up to: 3.6
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin extends functionality to Tokokoo Themes. It provides a several optional custom post types, custom css, shortcodes, etc.

==Description==

We decided to seperate between core features and extensions features. It's extends functionality to the collection of Tokokoo Themes. It provides a several optional custom post types, custom css, shortcodes, facebook app and customizer functionality.(More descriptions to come)

**Note 1:** This plugin only works with <a href="http://tokokoo.com/tokokoo-themes/">Tokokoo Themes</a>!
**Note 2:** If you already our customer, please DO NOT download and use it before we announce which theme already support it!

== Installation ==

1. Upload the 'tokokoo-extensions' folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What is this plugin and why do I need it? =

The Tokokoo Extensions provides extra functionality to the collection of Tokokoo Themes. It is required to use Tokokoo themes.

= How do I use it? =

Once you install it, the extensions features are automatically activated.

== Changelog ==

= v1.0.1 - Aug 25, 2013 =
* Update ACF
* Moved addons to plugin

= v1.0 - July 26, 2013 =
* Original Release.