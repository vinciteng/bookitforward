Terms:
	1. All add-ons are not to be used or distributed outside of Tokokoo Themes!