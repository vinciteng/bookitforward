<?php

/**
 * Catalog Mode Extension
 */
class WCXP_Catalog_Mode extends WCXP_Extension {

	/**
	 * Init and hook in the integration.
	 */
	public function __construct() {
        $this->id					= 'wcxp_catalog_mode';
        $this->method_title     	= __( 'Catalog Mode', 'wcxp_catalog_mode' );
        $this->method_description	= __( 'Transform your store to Catalog Mode. Some options have "default" value. We will do nothing when you choose this value. The visibility for each of these options with "default" value will be controlled by your theme and any supported plugin.', 'wcxp_catalog_mode' );

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables
		$this->cm_category			= $this->get_option( 'wcxp_catalog_mode_category' );
		$this->cm_product			= $this->get_option( 'wcxp_catalog_mode_product' );
		$this->cm_price				= $this->get_option( 'wcxp_catalog_price' );
		$this->cm_price_text		= $this->get_option( 'wcxp_catalog_price_text' );
		$this->cm_button			= $this->get_option( 'wcxp_catalog_button' );
		$this->cm_cart_redirect		= $this->get_option( 'wcxp_catalog_cart_redirect' );
		
		// Actions
		add_action( "woocommerce_update_options_wcxp_extension_{$this->id}", array( $this, 'process_admin_options') );

		// Catalog Mode Settings To Product Category Admin Page
		if ( $this->cm_category == 'yes' ) {
			add_action( 'product_cat_add_form_fields', array( $this, 'settings_category_add' ), 20 );
			add_action( 'product_cat_edit_form_fields', array( $this, 'settings_category_edit' ), 20, 2 );
			add_action( 'created_term', array( $this, 'settings_category_save' ), 10,3 );
			add_action( 'edit_term', array( $this, 'settings_category_save' ), 10,3 );
		}
		
		// Add Catalog Mode Settings To Product Data Tab
		if ( $this->cm_product == 'yes' ) {
			add_action( 'woocommerce_product_write_panel_tabs', array($this, 'settings_product_tab') );
			add_action( 'woocommerce_product_write_panels', array($this, 'settings_product') );
			add_action( 'woocommerce_process_product_meta', array($this, 'settings_product_save'), 10, 2 );
		}
		
		// Setup Catalog Mode
		add_action( 'wp' , array( $this, 'setup' ) , 20);

		// Setup Redirect
		add_action( 'template_redirect', array( $this, 'redirect' ) );
		
    }

    /**
     * Initialise Settings Form Fields
     */
    function init_form_fields() {

    	$this->form_fields = array(
			'wcxp_catalog_mode_category' => array(
				'title' 			=> __( 'Catalog Mode Per Category', 'wcxp_catalog_mode' ),
				'label' 			=> __( 'Enable catalog mode options on product category', 'wcxp_catalog_mode' ),
				'type' 				=> 'checkbox',
				'checkboxgroup'		=> '',
				'default' 			=> 'no'
			),
			'wcxp_catalog_mode_product' => array(
				'title' 			=> __( 'Catalog Mode Per Product', 'wcxp_catalog_mode' ),
				'label' 			=> __( 'Enable catalog mode options on single product', 'wcxp_catalog_mode' ),
				'type' 				=> 'checkbox',
				'checkboxgroup'		=> '',
				'default'			=> 'no',
			),
			'wcxp_catalog_price' => array(
				'title' 			=> __( 'Price', 'wcxp_catalog_mode' ),
				'type' 				=> 'select',
				'options' 			=> array(
					'default'				=> __('Default', 'wcxp_catalog_mode'),
					'hide' 					=> __('Hide', 'wcxp_catalog_mode'),
					'hide-notloggedin'		=> __('Hide for not logged-in user', 'wcxp_catalog_mode'),
					'custom' 				=> __('Custom text', 'wcxp_catalog_mode'),
					'custom-notloggedin'	=> __('Custom text for not logged-in user', 'wcxp_catalog_mode'),
				)
			),
			'wcxp_catalog_price_text' => array(
				'title'				=> __( 'Custom Price Text', 'wcxp_catalog_mode' ),
				'type' 				=> 'text',
				'default'			=> '',
			),
			'wcxp_catalog_button' => array(
				'title' 			=> __( '"Add To Cart" Button', 'wcxp_catalog_mode' ),
				'type' 				=> 'select',
				'options' 			=> array(
					'default'				=> __('Default', 'wcxp_catalog_mode'),
					'hide' 					=> __('Hide', 'wcxp_catalog_mode'),
					'hide-notloggedin'		=> __('Hide for not logged-in user', 'wcxp_catalog_mode'),
				)
			),
			'wcxp_catalog_cart_redirect' => array(
				'title'				=> __( 'Redirect Cart &amp; Checkout To', 'wcxp_catalog_mode' ),
				'description' 		=> __( 'Custom url to redirect when visitor try to access your cart and checkout page.', 'wcxp_catalog_mode' ),
				'type' 				=> 'text',
				'default'			=> '',
			),
		);

    } // End init_form_fields()

	/**
	 * Add Catalog Mode Options to Products - Category - Add page
	 **/
	function settings_category_add() {
		?>
		<h3><?php _e( 'Catalog Mode Options', 'wcxp_catalog_mode' ); ?></h3>
		<div class="form-field">
			<label for="wcxp_catalog_price"><?php _e( 'Price', 'wcxp_catalog_mode' ); ?></label>
			<select id="wcxp_catalog_price" name="wcxp_catalog_price" class="postform">
				<option value="default"><?php _e( 'Default', 'wcxp_catalog_mode' ); ?></option>
				<option value="hide"><?php _e( 'Hide', 'wcxp_catalog_mode' ); ?></option>
				<option value="hide-notloggedin"><?php _e( 'Hide for not logged-in user', 'wcxp_catalog_mode' ); ?></option>
				<option value="custom"><?php _e( 'Custom text', 'wcxp_catalog_mode' ); ?></option>
				<option value="custom-notloggedin"><?php _e( 'Custom text for not logged-in user', 'wcxp_catalog_mode' ); ?></option>
			</select>
		</div>
		<div class="form-field">
			<label for="wcxp_catalog_price_text"><?php _e( 'Custom Price Text', 'wcxp_catalog_mode' ); ?></label>
			<input type="text" size="40" value="" id="wcxp_catalog_price_text" name="wcxp_catalog_price_text">
		</div>
		<div class="form-field">
			<label for="wcxp_catalog_button"><?php _e( '"Add To Cart" Button', 'wcxp_catalog_mode' ); ?></label>
			<select id="wcxp_catalog_button" name="wcxp_catalog_button" class="postform">
				<option value="default"><?php _e( 'Default', 'wcxp_catalog_mode' ); ?></option>
				<option value="hide"><?php _e( 'Hide', 'wcxp_catalog_mode' ); ?></option>
				<option value="hide-notloggedin"><?php _e( 'Hide for not logged-in user', 'wcxp_catalog_mode' ); ?></option>
			</select>
		</div>
		<?php
	}
	
	/**
	 * Add Catalog Mode Options to Products - Category - Edit page
	 **/
	function settings_category_edit( $term, $taxonomy ) {
		global $woocommerce;
		$wcxp_catalog_price		= get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_price', true );
		$wcxp_catalog_price_text	= get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_price_text', true );
		$wcxp_catalog_button		= get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true );
		?>
		<tr>
			<td colspan="2"><h3><?php _e( 'Catalog Mode Options', 'wcxp_catalog_mode' ); ?></h3></td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label><?php _e( 'Price', 'wcxp_catalog_mode' ); ?></label></th>
			<td>
				<select id="wcxp_catalog_price" name="wcxp_catalog_price" class="postform">
					<option value="default" <?php selected( 'default', $wcxp_catalog_price ); ?>><?php _e( 'Default', 'wcxp_catalog_mode' ); ?></option>
					<option value="hide" <?php selected( 'hide', $wcxp_catalog_price ); ?>><?php _e( 'Hide', 'wcxp_catalog_mode' ); ?></option>
					<option value="hide-notloggedin" <?php selected( 'hide-notloggedin', $wcxp_catalog_price ); ?>><?php _e( 'Hide for not logged-in user', 'wcxp_catalog_mode' ); ?></option>
					<option value="custom" <?php selected( 'custom', $wcxp_catalog_price ); ?>><?php _e( 'Custom text', 'wcxp_catalog_mode' ); ?></option>
					<option value="custom-notloggedin" <?php selected( 'custom-notloggedin', $wcxp_catalog_price ); ?>><?php _e( 'Custom text for not logged-in user', 'wcxp_catalog_mode' ); ?></option>
				</select>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="wcxp_catalog_price_text"><?php _e( 'Custom Price Text', 'wcxp_catalog_mode' ); ?></label></th>
			<td>
				<input type="text" size="40" value="<?php echo $wcxp_catalog_price_text; ?>" id="wcxp_catalog_price_text" name="wcxp_catalog_price_text">
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label><?php _e( '"Add To Cart" Button', 'wcxp_catalog_mode' ); ?></label></th>
			<td>
				<select id="wcxp_catalog_button" name="wcxp_catalog_button" class="postform">
					<option value="default" <?php selected( 'default', $wcxp_catalog_button ); ?>><?php _e( 'Default', 'wcxp_catalog_mode' ); ?></option>
					<option value="hide" <?php selected( 'hide', $wcxp_catalog_button ); ?>><?php _e( 'Hide', 'wcxp_catalog_mode' ); ?></option>
					<option value="hide-notloggedin" <?php selected( 'hide-notloggedin', $wcxp_catalog_button ); ?>><?php _e( 'Hide for not logged-in user', 'wcxp_catalog_mode' ); ?></option>
				</select>
			</td>
		</tr>
		<?php
	}
	
	/**
	 * Save Catalog Mode Options on Products - Category - Add/Edit page
	 **/
	function settings_category_save( $term_id, $tt_id, $taxonomy ) {
		if ( isset( $_POST['wcxp_catalog_price'] ) )
			update_woocommerce_term_meta( $term_id, 'wcxp_catalog_price', esc_attr( $_POST['wcxp_catalog_price'] ) );
		if ( isset( $_POST['wcxp_catalog_price_text'] ) )
			update_woocommerce_term_meta( $term_id, 'wcxp_catalog_price_text', esc_attr( $_POST['wcxp_catalog_price_text'] ) );
		if ( isset( $_POST['wcxp_catalog_button'] ) )
			update_woocommerce_term_meta( $term_id, 'wcxp_catalog_button', esc_attr( $_POST['wcxp_catalog_button'] ) );
		delete_transient( 'wc_term_counts' );
	}
	
	/**
	 * Add Catalog Mode Options to Product Panel Tab
	 **/
	function settings_product_tab() {
		echo '<li class="wcxp_catalog_mode advanced_options"><a href="#wcxp_catalog_mode">'.__('Catalog Mode', 'wcxp_catalog_mode').'</a></li>';
	}
	
	/**
	 * Add Catalog Mode Options to Product Panel
	 **/
	function settings_product() {
		echo '<div id="wcxp_catalog_mode" class="panel woocommerce_options_panel">';
		echo '<div class="options_group">';
		woocommerce_wp_select( array( 
			'id' => '_wcxp_catalog_price', 
			'label' => __( 'Price', 'wcxp_catalog_mode' ), 
			'options' => array(
				'default'			=> __('Default', 'wcxp_catalog_mode'),
				'hide' 				=> __('Hide', 'wcxp_catalog_mode'),
				'hide-notloggedin'	=> __('Hide for not logged-in user', 'wcxp_catalog_mode'),
				'custom' 			=> __('Custom text', 'wcxp_catalog_mode'),
				'custom-notloggedin'=> __('Custom text for not logged-in user', 'wcxp_catalog_mode'),
			),
		) );
		woocommerce_wp_text_input( array( 
			'id' => '_wcxp_catalog_price_text', 
			'label' => __( 'Custom Price Text', 'wcxp_catalog_mode' ), 
		) );
		woocommerce_wp_select( array( 
			'id' => '_wcxp_catalog_button', 
			'label' => __( '"Add To Cart" Button', 'wcxp_catalog_mode' ), 
			'options' => array(
				'default'			=> __('Default', 'wcxp_catalog_mode'),
				'hide' 				=> __('Hide', 'wcxp_catalog_mode'),
				'hide-notloggedin'	=> __('Hide for not logged-in user', 'wcxp_catalog_mode'),
			),
		) );
		echo '</div>';
		echo '</div>';
	}
	
	/**
	 * Save Catalog Mode Options on Product Panel
	 **/
	function settings_product_save( $post_id, $post ) {
		if ( isset( $_POST['_wcxp_catalog_price'] ) )
			update_post_meta( $post_id, '_wcxp_catalog_price', esc_attr( $_POST['_wcxp_catalog_price'] ) );
		if ( isset( $_POST['_wcxp_catalog_price_text'] ) )
			update_post_meta( $post_id, '_wcxp_catalog_price_text', esc_attr( $_POST['_wcxp_catalog_price_text'] ) );
		if ( isset( $_POST['_wcxp_catalog_button'] ) )
			update_post_meta( $post_id, '_wcxp_catalog_button', esc_attr( $_POST['_wcxp_catalog_button'] ) );
	}
	
	/**
	 * Setup Catalog Mode on Frontend
	 **/
	function setup() {
		if ( is_admin() )
			return;
		add_filter( 'woocommerce_get_price_html', array( $this, 'hide_price' ) );
		add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'hide_button' ) );
		add_action( 'woocommerce_before_shop_loop_item', array( $this, 'hide_button_outofstock' ) );
		if ( is_singular('product') )
			$this->hide_button_single();
	}
	
	/**
	 * Hide price using "woocommerce_get_price_html" filter
	 **/
	function hide_price( $price ) {
		global $product;
		/* Product options */
		if ( $this->cm_product == 'yes' ) {
			$catalog_price = get_post_meta( $product->id, '_wcxp_catalog_price', true );
			if ( !$catalog_price || ( $catalog_price && $catalog_price != 'default' ) ) {
				$catalog_price_text = get_post_meta( $product->id, '_wcxp_catalog_price_text', true );
				if ( $catalog_price == 'hide' )
					return false;
				elseif ( !is_user_logged_in() && $catalog_price == 'hide-notloggedin' )
					return false;
				elseif ( $catalog_price == 'custom' && $catalog_price_text )
					return $catalog_price_text;
				elseif ( !is_user_logged_in() && $catalog_price == 'custom-notloggedin' && $catalog_price_text )
					return $catalog_price_text;
			}
		}
		/* Category options */
		if ( $this->cm_category == 'yes' ) {
			$terms = get_the_terms( $product->id, 'product_cat' );
			if ( !is_wp_error( $terms ) && !empty( $terms ) ) {
				foreach ( $terms as $term ) {
					$catalog_price = get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_price', true );
					if ( !$catalog_price || ( $catalog_price && $catalog_price != 'default' ) ) {
						$catalog_price_text = get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_price_text', true );
						if ( $catalog_price == 'hide' )
							return false;
						elseif ( !is_user_logged_in() && $catalog_price == 'hide-notloggedin' )
							return false;
						elseif ( $catalog_price == 'custom' && $catalog_price_text )
							return $catalog_price_text;
						elseif ( !is_user_logged_in() && $catalog_price == 'custom-notloggedin' && $catalog_price_text )
							return $catalog_price_text;
					}
				}
			}
		}
		/* Global options */
		$catalog_price = $this->cm_price;
		if ( !$catalog_price || ( $catalog_price && $catalog_price != 'default' ) ) {
			$catalog_price_text = $this->cm_price_text;
			if ( $catalog_price == 'hide' )
				return false;
			elseif ( !is_user_logged_in() && $catalog_price == 'hide-notloggedin' )
				return false;
			elseif ( $catalog_price == 'custom' && $catalog_price_text )
				return $catalog_price_text;
			elseif ( !is_user_logged_in() && $catalog_price == 'custom-notloggedin' && $catalog_price_text )
				return $catalog_price_text;
		}
		return $price;
	}
	
	/**
	 * Hide button using "woocommerce_loop_add_to_cart_link" filter, available for instock product
	 **/
	function hide_button( $button ) {
		global $product;
		/* Product options */
		if ( $this->cm_product == 'yes' ) {
			if ( get_post_meta( $product->id, '_wcxp_catalog_button', true ) == 'hide' )
				return false;
			elseif ( !is_user_logged_in() && get_post_meta( $product->id, '_wcxp_catalog_button', true ) == 'hide-notloggedin' )
				return false;
		}
		/* Category options */
		if ( $this->cm_category == 'yes' ) {
			$terms = get_the_terms( $product->id, 'product_cat' );
			if ( !is_wp_error( $terms ) && !empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true ) == 'hide' )
						return false;
					elseif ( !is_user_logged_in() && get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true ) == 'hide-notloggedin' )
						return false;
				}
			}
		}
		/* Global options */
		if ( $this->cm_button == 'hide' )
			return false;
		elseif ( !is_user_logged_in() && $this->cm_button == 'hide-notloggedin' )
			return false;
		return $button;
	}
	
	/**
	 * Hide button on outofstock product using CSS. It is workaround, we will submit a patch to WooCommerce on Github to make it better.
	 **/
	function hide_button_outofstock() {
		global $product;
		if ( $product->is_in_stock() )
			return;
		$hide = false;
		/* Global options */
		if ( $this->cm_button == 'hide' )
			$hide = true;
		elseif ( !is_user_logged_in() && $this->cm_button == 'hide-notloggedin' )
			$hide = true;
		/* Category options */
		if ( $this->cm_category == 'yes' ) {
			$terms = get_the_terms( $product->id, 'product_cat' );
			if ( !is_wp_error( $terms ) && !empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true ) == 'hide' )
						$hide = true;
					elseif ( !is_user_logged_in() && get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true ) == 'hide-notloggedin' )
						$hide = true;
				}
			}
		}
		/* Product options */
		if ( $this->cm_product == 'yes' ) {
			if ( get_post_meta( $product->id, '_wcxp_catalog_button', true ) == 'hide' )
				$hide = true;
			elseif ( !is_user_logged_in() && get_post_meta( $product->id, '_wcxp_catalog_button', true ) == 'hide-notloggedin' )
				$hide = true;
		}
		if ( $hide )
			echo '<style>ul.products li.post-'.$product->id.' a.button{ display: none; }</style>';
	}
	
	/**
	 * Hide button on single product page.
	 **/
	function hide_button_single() {
		$hide = false;
		/* Global options */
		if ( $this->cm_button == 'hide' )
			$hide = true;
		elseif ( !is_user_logged_in() && $this->cm_button == 'hide-notloggedin' )
			$hide = true;
		/* Category options */
		if ( $this->cm_category == 'yes' ) {
			$terms = get_the_terms( get_the_ID(), 'product_cat' );
			if ( !is_wp_error( $terms ) && !empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true ) == 'hide' )
						$hide = true;
					elseif ( !is_user_logged_in() && get_woocommerce_term_meta( $term->term_id, 'wcxp_catalog_button', true ) == 'hide-notloggedin' )
						$hide = true;
				}
			}
		}
		/* Product options */
		if ( $this->cm_product == 'yes' ) {
			if ( get_post_meta( get_the_ID(), '_wcxp_catalog_button', true ) == 'hide' )
				$hide = true;
			elseif ( !is_user_logged_in() && get_post_meta( get_the_ID(), '_wcxp_catalog_button', true ) == 'hide-notloggedin' )
				$hide = true;
		}
		if ( !$hide )
			return;
		remove_action( 'woocommerce_simple_add_to_cart', 'woocommerce_simple_add_to_cart', 30 );
		remove_action( 'woocommerce_grouped_add_to_cart', 'woocommerce_grouped_add_to_cart', 30 );
		remove_action( 'woocommerce_variable_add_to_cart', 'woocommerce_variable_add_to_cart', 30 );
		remove_action( 'woocommerce_external_add_to_cart', 'woocommerce_external_add_to_cart', 30 );
	}
	
	/**
	 * Redirect cart / checkout page.
	 **/
	function redirect() {
		if ( !is_cart() && !is_checkout() )
			return;
		if ( $url = $this->cm_cart_redirect ) {
			wp_redirect( esc_url_raw( $url ), 301 );
			exit;
		}
	}

}
