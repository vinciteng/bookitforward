<?php
/**
 * WooCommerce Extension Settings
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'WCXP_Settings_Extensions' ) ) :

/**
 * WCXP_Settings_Extensions
 */
class WCXP_Settings_Extensions extends WC_Settings_Page {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id    = 'wcxp_extension';
		$this->label = WCXP_EXTENSIONS_TITLE;
		
		if ( isset( WC()->wcxp_extensions ) && WC()->wcxp_extensions->get_extensions() ) {
			add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 20 );
			add_action( 'woocommerce_sections_' . $this->id, array( $this, 'output_sections' ) );
			add_action( 'woocommerce_settings_' . $this->id, array( $this, 'output' ) );
			add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
		}
	}

	/**
	 * Get sections
	 *
	 * @return array
	 */
	public function get_sections() {
		global $current_section;

		$sections = array();

		$extensions = WC()->wcxp_extensions->get_extensions();

		if ( ! $current_section )
			$current_section = current( $extensions )->id;

		foreach ( $extensions as $extension ) {
			$title = empty( $extension->method_title ) ? ucfirst( $extension->id ) : $extension->method_title;

			$sections[ strtolower( $extension->id ) ] = esc_html( $title );
		}

		return $sections;
	}

	/**
	 * Output the settings
	 */
	public function output() {
		global $current_section;

		$extensions = WC()->wcxp_extensions->get_extensions();

		if ( isset( $extensions[ $current_section ] ) )
			$extensions[ $current_section ]->admin_options();
	}
}

endif;

return new WCXP_Settings_Extensions();