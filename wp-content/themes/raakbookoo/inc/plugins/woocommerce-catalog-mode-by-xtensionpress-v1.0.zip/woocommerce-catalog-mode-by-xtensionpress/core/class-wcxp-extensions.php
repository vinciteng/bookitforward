<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * XtensionPress - WooCommerce Extensions class
 */
class WCXP_Extensions {

	/** @var array Array of extension classes */
	var $extensions = array();

    /**
     * __construct function.
     */
    public function __construct() {

		do_action( 'wcxp_extensions_init' );

		$load_extensions = apply_filters( 'wcxp_extensions', array() );

		// Load extension classes
		foreach ( $load_extensions as $extension ) {

			$load_extension = new $extension();

			$this->extensions[ $load_extension->id ] = $load_extension;
		}

	}

	/**
	 * Return loaded extensions.
	 */
	public function get_extensions() {
		return $this->extensions;
	}
}

/**
 * XtensionPress - WooCommerce Extension class
 */
abstract class WCXP_Extension extends WC_Settings_API {

	/**
	 * Admin Options
	 */
	public function admin_options() { ?>

		<?php echo isset( $this->method_title ) ? '<h3>'.$this->method_title.'</h3>' : ''; ?>
		
		<?php echo isset( $this->method_description ) ? wpautop( $this->method_description ) : ''; ?>

		<table class="form-table">
			<?php $this->generate_settings_html(); ?>
		</table>

		<!-- Section -->
		<div><input type="hidden" name="section" value="<?php echo $this->id; ?>" /></div>

		<?php
	}
}