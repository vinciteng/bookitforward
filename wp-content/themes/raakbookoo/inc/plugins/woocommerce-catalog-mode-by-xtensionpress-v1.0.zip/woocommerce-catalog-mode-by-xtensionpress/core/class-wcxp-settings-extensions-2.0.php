<?php
/**
 * WooCommerce Extension Settings
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'WCXP_Settings_Extensions' ) ) :

/**
 * WCXP_Settings_Extensions
 */
class WCXP_Settings_Extensions {

	protected $id    = '';
	protected $label = '';

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $woocommerce;
		$this->id    = 'wcxp_extension';
		$this->label = WCXP_EXTENSIONS_TITLE;
		
		if ( isset( $woocommerce->wcxp_extensions ) && $woocommerce->wcxp_extensions->get_extensions() ) {
			add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 20 );
			add_action( 'woocommerce_settings_tabs_' . $this->id, array( $this, 'output' ) );
			add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
		}
	}

	/**
	 * Add this page to settings
	 */
	public function add_settings_page( $pages ) {
		$pages[ $this->id ] = $this->label;

		return $pages;
	}

	/**
	 * Output
	 */
	public function output() {
		global $current_section, $woocommerce;
		
		$extensions = $woocommerce->wcxp_extensions->get_extensions();
		
		$current_section = empty( $current_section ) ? key( $extensions ) : $current_section;		
		
		$links = array();

		foreach ( $extensions as $extension ) {
			$title = empty( $extension->method_title ) ? ucwords( $extension->id ) : ucwords( $extension->method_title );

			$current = ( $extension->id == $current_section ) ? 'class="current"' : '';

			$links[] = '<a href="' . add_query_arg( 'section', $extension->id, admin_url('admin.php?page=woocommerce_settings&tab=wcxp_extension') ) . '"' . $current . '>' . esc_html( $title ) . '</a>';
		}

		echo '<ul class="subsubsub"><li>' . implode( ' | </li><li>', $links ) . '</li></ul><br class="clear" />';

		if ( isset( $extensions[ $current_section ] ) )
			$extensions[ $current_section ]->admin_options();
	}

	/**
	 * Save settings
	 */
	public function save() {
		global $current_section;

		 if ( $current_section )
	    	do_action( 'woocommerce_update_options_' . $this->id . '_' . $current_section );
	}
}

endif;

return new WCXP_Settings_Extensions();