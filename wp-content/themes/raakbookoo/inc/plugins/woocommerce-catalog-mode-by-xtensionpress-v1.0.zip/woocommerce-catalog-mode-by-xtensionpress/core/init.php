<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( !function_exists( 'wcxp_extensions_class_init' ) ) {
	add_action( 'woocommerce_init', 'wcxp_extensions_class_init' );
	function wcxp_extensions_class_init() {
		if ( !class_exists( 'WCXP_Extensions' ) && !class_exists( 'WCXP_Extension' ) ) {
			include_once( 'class-wcxp-extensions.php' );
			global $woocommerce;
			$woocommerce->wcxp_extensions = new WCXP_Extensions();
		}
	}
}

if ( !function_exists( 'wcxp_extensions_get_settings_pages' ) ) {
	add_filter( 'woocommerce_get_settings_pages', 'wcxp_extensions_get_settings_pages' ); 
	function wcxp_extensions_get_settings_pages( $settings ) {
		if ( !class_exists( 'WCXP_Settings_Extensions' ) ) {
			$settings[] = include( 'class-wcxp-settings-extensions.php' );
		}
		return $settings;
	}
}

if ( !function_exists( 'wcxp_extensions_settings_page' ) ) {
	add_action( 'woocommerce_init', 'wcxp_extensions_settings_page', 20 ); 
	function wcxp_extensions_settings_page() {
		global $woocommerce;
		if ( is_object( $woocommerce ) && version_compare( $woocommerce->version, '2.1', '>=' ) )
			return;
		include_once( 'class-wcxp-settings-extensions-2.0.php' );
	}
}
