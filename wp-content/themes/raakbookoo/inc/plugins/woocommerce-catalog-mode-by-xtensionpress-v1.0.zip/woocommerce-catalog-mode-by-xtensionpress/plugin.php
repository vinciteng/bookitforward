<?php
/*
Plugin Name: WooCommerce Catalog Mode by XtensionPress
Plugin URI: http://xtensionpress.com
Description: Transform your WooCommerce store to Catalog Mode. LightWeight and WhiteLabel.
Version: 1.0
Author: XtensionPress
Author URI: http://xtensionpress.com
Text Domain: wcxp_catalog_mode
Domain Path: /languages/

	Copyright: © 2014 XtensionPress.
	License: GNU General Public License v3.0
	License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * TODO: Find a better way to handle this
 **/
if ( ! defined( 'WCXP_EXTENSIONS_TITLE' ) )
	define( 'WCXP_EXTENSIONS_TITLE', __( 'Extensions', 'wcxp_catalog_mode' ) );
	
/**
 * Load Languages
 **/
load_plugin_textdomain( 'wcxp_catalog_mode', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

/**
 * Load XtensionPress Core files
 **/
include_once( 'core/init.php' );

/**
 * Add the extension to WooCommerce
 **/
add_filter( 'wcxp_extensions', 'wcxp_catalog_mode_add_extension', 10 );
function wcxp_catalog_mode_add_extension( $extensions ) {
	global $woocommerce;

	if ( is_object( $woocommerce ) ) {
		include_once( 'includes/class-wcxp-catalog-mode.php' );
		$extensions[] = 'WCXP_Catalog_Mode';
	}

	return $extensions;
}
